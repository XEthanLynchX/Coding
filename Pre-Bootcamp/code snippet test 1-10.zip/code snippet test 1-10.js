function hello() {
    console.log('hello');
}
hello();
console.log('Dojo');
