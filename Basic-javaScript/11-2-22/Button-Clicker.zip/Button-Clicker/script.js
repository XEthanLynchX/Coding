function hide(element) {
    element.remove();
}

function logOut(element) {
    element.innerText = "Logout";
}
